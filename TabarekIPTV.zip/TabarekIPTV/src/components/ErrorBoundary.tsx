import React, { Component, ErrorInfo, ReactNode } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExclamationTriangle, faRedoAlt } from '@fortawesome/free-solid-svg-icons';
import { setFocus } from '@noriginmedia/norigin-spatial-navigation';
import './ErrorBoundary.scss';

interface Props {
    children: ReactNode;
    onReset?: () => void;
    focusKeyPrefix?: string;
}

interface State {
    hasError: boolean;
    error: Error | null;
    errorInfo: ErrorInfo | null;
    retryCount: number;
}

export class ErrorBoundary extends Component<Props, State> {
    public state: State = {
        hasError: false,
        error: null,
        errorInfo: null,
        retryCount: 0
    };

    private retryButtonRef = React.createRef<HTMLButtonElement>();
    private focusKey = `${this.props.focusKeyPrefix || 'error'}-retry`;
    private maxRetries = 3;

    public static getDerivedStateFromError(error: Error): Partial<State> {
        return {
            hasError: true,
            error
        };
    }

    public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
        this.setState(prevState => ({
            error,
            errorInfo,
            retryCount: prevState.retryCount + 1
        }));
        
        // Log error to error reporting service
        console.error('Uncaught error:', error, errorInfo);

        // Focus retry button when error occurs
        setTimeout(() => {
            if (this.retryButtonRef.current) {
                setFocus(this.focusKey);
            }
        }, 100);
    }

    public componentWillUnmount() {
        // Cleanup any timers or subscriptions
        this.setState = () => null;
    }

    private handleReset = () => {
        if (this.state.retryCount >= this.maxRetries) {
            // After max retries, refresh the page
            window.location.reload();
            return;
        }

        this.setState({
            hasError: false,
            error: null,
            errorInfo: null
        });
        
        if (this.props.onReset) {
            this.props.onReset();
        }
    };

    private getErrorMessage(): string {
        if (this.state.error instanceof TypeError) {
            return 'There was a problem processing the data.';
        }
        if (this.state.error instanceof ReferenceError) {
            return 'There was a problem with the application code.';
        }
        return 'An unexpected error occurred.';
    }

    public render() {
        if (this.state.hasError) {
            return (
                <div className="error-boundary" role="alert">
                    <div className="error-content">
                        <FontAwesomeIcon 
                            icon={faExclamationTriangle} 
                            className="error-icon"
                            size="3x"
                        />
                        <h1>Something went wrong</h1>
                        <p>{this.getErrorMessage()}</p>
                        
                        {process.env.NODE_ENV === 'development' && this.state.error && (
                            <div className="error-details">
                                <pre>{this.state.error.toString()}</pre>
                                {this.state.errorInfo && (
                                    <pre>{this.state.errorInfo.componentStack}</pre>
                                )}
                            </div>
                        )}

                        {this.state.retryCount < this.maxRetries ? (
                            <button 
                                ref={this.retryButtonRef}
                                className="retry-button"
                                onClick={this.handleReset}
                                data-focusable="true"
                                data-focus-key={this.focusKey}
                            >
                                <FontAwesomeIcon icon={faRedoAlt} />
                                <span>Try Again ({this.maxRetries - this.state.retryCount} attempts remaining)</span>
                            </button>
                        ) : (
                            <button 
                                ref={this.retryButtonRef}
                                className="retry-button refresh"
                                onClick={this.handleReset}
                                data-focusable="true"
                                data-focus-key={this.focusKey}
                            >
                                <FontAwesomeIcon icon={faRedoAlt} />
                                <span>Refresh Application</span>
                            </button>
                        )}
                    </div>
                </div>
            );
        }

        return this.props.children;
    }
}

export default ErrorBoundary;