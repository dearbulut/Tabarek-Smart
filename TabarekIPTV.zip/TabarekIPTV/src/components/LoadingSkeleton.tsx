import React from 'react';
import './LoadingSkeleton.scss';

interface LoadingSkeletonProps {
    type: 'card' | 'detail' | 'list' | 'grid';
    count?: number;
    className?: string;
}

export const LoadingSkeleton: React.FC<LoadingSkeletonProps> = ({
    type,
    count = 1,
    className = ''
}) => {
    const renderSkeleton = () => {
        switch (type) {
            case 'card':
                return (
                    <div className="skeleton-card">
                        <div className="skeleton-image pulse" />
                        <div className="skeleton-content">
                            <div className="skeleton-title pulse" />
                            <div className="skeleton-text pulse" />
                        </div>
                    </div>
                );
            
            case 'detail':
                return (
                    <div className="skeleton-detail">
                        <div className="skeleton-backdrop pulse" />
                        <div className="skeleton-content">
                            <div className="skeleton-title-large pulse" />
                            <div className="skeleton-meta">
                                <div className="skeleton-meta-item pulse" />
                                <div className="skeleton-meta-item pulse" />
                                <div className="skeleton-meta-item pulse" />
                            </div>
                            <div className="skeleton-description">
                                <div className="skeleton-text pulse" />
                                <div className="skeleton-text pulse" />
                                <div className="skeleton-text pulse" />
                            </div>
                        </div>
                    </div>
                );

            case 'list':
                return (
                    <div className="skeleton-list">
                        <div className="skeleton-list-item">
                            <div className="skeleton-thumbnail pulse" />
                            <div className="skeleton-content">
                                <div className="skeleton-title pulse" />
                                <div className="skeleton-text pulse" />
                            </div>
                        </div>
                    </div>
                );

            case 'grid':
                return (
                    <div className="skeleton-grid">
                        {Array.from({ length: count }).map((_, index) => (
                            <div key={index} className="skeleton-grid-item">
                                <div className="skeleton-image pulse" />
                                <div className="skeleton-title pulse" />
                            </div>
                        ))}
                    </div>
                );

            default:
                return null;
        }
    };

    return (
        <div className={`loading-skeleton ${type} ${className}`}>
            {Array.from({ length: type !== 'grid' ? count : 1 }).map((_, index) => (
                <div key={index} className="skeleton-wrapper">
                    {renderSkeleton()}
                </div>
            ))}
        </div>
    );
};

export default LoadingSkeleton;