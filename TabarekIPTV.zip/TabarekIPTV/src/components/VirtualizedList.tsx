import React, { useEffect, useRef, useState, useCallback, memo } from 'react';
import { useFocusable, setFocus } from '@noriginmedia/norigin-spatial-navigation';
import './VirtualizedList.scss';

interface VirtualizedListProps<T> {
    items: T[];
    renderItem: (item: T, index: number, isVisible: boolean) => React.ReactNode;
    itemHeight: number;
    itemWidth: number;
    overscan?: number;
    layout?: 'grid' | 'list';
    columns?: number;
    gap?: number;
    className?: string;
    onItemFocus?: (item: T, index: number) => void;
    onItemSelect?: (item: T, index: number) => void;
    getItemKey?: (item: T, index: number) => string;
    focusKey?: string;
    initialFocusIndex?: number;
}

function VirtualizedList<T>({
    items,
    renderItem,
    itemHeight,
    itemWidth,
    overscan = 5,
    layout = 'grid',
    columns = 1,
    gap = 20,
    className = '',
    onItemFocus,
    onItemSelect,
    getItemKey = (_, index) => index.toString(),
    focusKey = 'virtualized-list',
    initialFocusIndex = 0
}: VirtualizedListProps<T>) {
    const containerRef = useRef<HTMLDivElement>(null);
    const [scrollTop, setScrollTop] = useState(0);
    const [containerHeight, setContainerHeight] = useState(0);
    const [visibleItems, setVisibleItems] = useState<{start: number; end: number}>({ start: 0, end: 0 });
    const [lastFocusedIndex, setLastFocusedIndex] = useState(initialFocusIndex);
    const scrollTimeout = useRef<number>();
    const isScrolling = useRef(false);

    const { ref: listRef, focusKey: listFocusKey } = useFocusable({
        trackChildren: true,
        isFocusBoundary: true,
        focusKey,
        preferredChildFocusKey: `${focusKey}-item-${lastFocusedIndex}`
    });

    // Optimized visible items calculation
    const calculateVisibleItems = useCallback(() => {
        if (!containerRef.current) return;

        const containerRect = containerRef.current.getBoundingClientRect();
        const rowHeight = itemHeight + gap;
        const itemsPerRow = layout === 'grid' ? columns : 1;
        const totalRows = Math.ceil(items.length / itemsPerRow);

        const visibleStart = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
        const visibleEnd = Math.min(
            totalRows,
            Math.ceil((scrollTop + containerHeight) / rowHeight) + overscan
        );

        setVisibleItems({
            start: visibleStart * itemsPerRow,
            end: Math.min(items.length, visibleEnd * itemsPerRow)
        });
    }, [scrollTop, containerHeight, itemHeight, gap, columns, items.length, layout, overscan]);

    // Optimized scroll handler with RAF and throttling
    const handleScroll = useCallback(() => {
        if (isScrolling.current) return;
        
        isScrolling.current = true;
        requestAnimationFrame(() => {
            if (containerRef.current) {
                setScrollTop(containerRef.current.scrollTop);
            }
            
            if (scrollTimeout.current) {
                clearTimeout(scrollTimeout.current);
            }
            
            scrollTimeout.current = window.setTimeout(() => {
                isScrolling.current = false;
            }, 150);
        });
    }, []);

    // Resize observer for container height updates
    useEffect(() => {
        const observer = new ResizeObserver((entries) => {
            const [entry] = entries;
            if (entry) {
                setContainerHeight(entry.contentRect.height);
            }
        });

        if (containerRef.current) {
            observer.observe(containerRef.current);
        }

        return () => {
            observer.disconnect();
            if (scrollTimeout.current) {
                clearTimeout(scrollTimeout.current);
            }
        };
    }, []);

    // Update visible items calculation
    useEffect(() => {
        calculateVisibleItems();
    }, [calculateVisibleItems, scrollTop, containerHeight]);

    // Focus restoration after scroll
    useEffect(() => {
        if (!isScrolling.current && lastFocusedIndex >= 0) {
            const focusedKey = `${focusKey}-item-${lastFocusedIndex}`;
            const element = document.querySelector(`[data-focus-key="${focusedKey}"]`);
            if (element && element.getBoundingClientRect().height > 0) {
                setFocus(focusedKey);
            }
        }
    }, [visibleItems, focusKey, lastFocusedIndex]);

    // Handle item focus
    const handleItemFocus = useCallback((item: T, index: number) => {
        setLastFocusedIndex(index);
        onItemFocus?.(item, index);

        // Scroll into view if needed
        const itemTop = Math.floor(index / columns) * (itemHeight + gap);
        const itemBottom = itemTop + itemHeight;
        
        if (containerRef.current) {
            const containerTop = containerRef.current.scrollTop;
            const containerBottom = containerTop + containerHeight;

            if (itemTop < containerTop) {
                containerRef.current.scrollTo({ top: itemTop, behavior: 'smooth' });
            } else if (itemBottom > containerBottom) {
                containerRef.current.scrollTo({
                    top: itemBottom - containerHeight + gap,
                    behavior: 'smooth'
                });
            }
        }
    }, [columns, itemHeight, gap, containerHeight, onItemFocus]);

    const getItemStyle = useCallback((index: number) => {
        if (layout === 'grid') {
            const row = Math.floor(index / columns);
            const col = index % columns;
            return {
                position: 'absolute' as const,
                top: row * (itemHeight + gap),
                left: col * (itemWidth + gap),
                width: itemWidth,
                height: itemHeight,
                transform: 'translate3d(0, 0, 0)', // Force GPU acceleration
                willChange: 'transform' // Optimize animations
            };
        }

        return {
            position: 'absolute' as const,
            top: index * (itemHeight + gap),
            left: 0,
            width: '100%',
            height: itemHeight,
            transform: 'translate3d(0, 0, 0)',
            willChange: 'transform'
        };
    }, [layout, columns, itemHeight, itemWidth, gap]);

    const totalHeight = layout === 'grid'
        ? Math.ceil(items.length / columns) * (itemHeight + gap) - gap
        : items.length * (itemHeight + gap) - gap;

    const visibleItemsList = items.slice(visibleItems.start, visibleItems.end);

    return (
        <div
            ref={listRef}
            className={`virtualized-list ${layout} ${className}`}
            data-focusable-container={true}
            data-focus-key={focusKey}
        >
            <div
                ref={containerRef}
                className="list-container"
                onScroll={handleScroll}
                style={{
                    height: '100%',
                    overflow: 'auto',
                    position: 'relative',
                    willChange: 'scroll-position'
                }}
            >
                <div
                    className="list-content"
                    style={{
                        height: totalHeight,
                        position: 'relative',
                        width: layout === 'grid' ? columns * (itemWidth + gap) - gap : '100%'
                    }}
                >
                    {visibleItemsList.map((item, index) => {
                        const absoluteIndex = index + visibleItems.start;
                        const itemKey = getItemKey(item, absoluteIndex);
                        
                        return (
                            <div
                                key={itemKey}
                                className="list-item"
                                style={getItemStyle(absoluteIndex)}
                                data-index={absoluteIndex}
                                data-focusable="true"
                                data-focus-key={`${focusKey}-item-${absoluteIndex}`}
                                onFocus={() => handleItemFocus(item, absoluteIndex)}
                            >
                                {renderItem(item, absoluteIndex, true)}
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

export default memo(VirtualizedList) as typeof VirtualizedList;