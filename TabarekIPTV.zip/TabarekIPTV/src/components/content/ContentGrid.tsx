import React, { useState } from 'react';
import { useFocusable, FocusContext } from '@noriginmedia/norigin-spatial-navigation';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlayCircle, faClosedCaptioning, faHd } from '@fortawesome/free-solid-svg-icons';
import '../styles/ContentGrid.scss';
import DetailsOverlay from './DetailsOverlay';

interface ContentItem {
    id: string;
    title: string;
    thumbnailUrl: string;
    type: 'live' | 'movie' | 'series';
    quality?: 'HD' | '4K';
    hasSubtitles?: boolean;
    progress?: number;
    description: string;
    backdropUrl: string;
    rating?: number;
    year?: number;
    duration?: number;
    genre?: string;
    cast?: string[];
    channelName?: string;
    startTime?: string;
    endTime?: string;
    category?: string;
}

interface ContentGridProps {
    items: ContentItem[];
    contentType: 'live' | 'movies' | 'series';
    onItemSelect: (item: ContentItem) => void;
    isLoading?: boolean;
}

export const ContentGrid: React.FC<ContentGridProps> = ({
    items,
    contentType,
    onItemSelect,
    isLoading = false
}) => {
    const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null);
    const [showOverlay, setShowOverlay] = useState(false);

    const { ref: gridRef, focusKey: gridFocusKey } = useFocusable({
        trackChildren: true,
        isFocusBoundary: true
    });

    const handleItemSelect = (item: ContentItem) => {
        setSelectedItem(item);
        setShowOverlay(true);
    };

    const handleOverlayClose = () => {
        setShowOverlay(false);
        setSelectedItem(null);
    };

    const handlePlay = (content: ContentItem) => {
        onItemSelect(content);
        handleOverlayClose();
    };

    const renderGridItem = (item: ContentItem) => {
        const { ref: itemRef, focused } = useFocusable({
            onEnterPress: () => handleItemSelect(item),
            focusKey: `content-${item.id}`
        });

        return (
            <div
                ref={itemRef}
                className={`grid-item ${focused ? 'focused' : ''} ${contentType}`}
                key={item.id}
                role="button"
                tabIndex={0}
            >
                <div className="thumbnail-container">
                    <img 
                        src={item.thumbnailUrl} 
                        alt={item.title}
                        className="thumbnail"
                        loading="lazy"
                    />
                    <div className="overlay">
                        <div className="item-info">
                            {item.quality && (
                                <span className="quality-badge">
                                    {item.quality === '4K' ? '4K' : <FontAwesomeIcon icon={faHd} />}
                                </span>
                            )}
                            {item.hasSubtitles && (
                                <span className="subtitle-badge">
                                    <FontAwesomeIcon icon={faClosedCaptioning} />
                                </span>
                            )}
                        </div>
                        <h3 className="title">{item.title}</h3>
                        {focused && (
                            <div className="focus-indicator">
                                <FontAwesomeIcon icon={faPlayCircle} className="play-icon" />
                            </div>
                        )}
                    </div>
                    {item.progress !== undefined && item.progress > 0 && (
                        <div className="progress-bar">
                            <div 
                                className="progress-fill"
                                style={{ width: `${item.progress}%` }}
                            />
                        </div>
                    )}
                </div>
            </div>
        );
    };

    if (isLoading) {
        return (
            <div className="content-grid loading">
                {Array.from({ length: 12 }).map((_, index) => (
                    <div key={`skeleton-${index}`} className="grid-item skeleton">
                        <div className="thumbnail-container">
                            <div className="skeleton-thumbnail" />
                            <div className="skeleton-overlay">
                                <div className="skeleton-title" />
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        );
    }

    return (
        <FocusContext.Provider value={gridFocusKey}>
            <div 
                ref={gridRef}
                className="content-grid"
                role="grid"
            >
                {items.length === 0 ? (
                    <div className="empty-state">
                        <p>No content available</p>
                    </div>
                ) : (
                    items.map(renderGridItem)
                )}
            </div>

            {selectedItem && (
                <DetailsOverlay
                    content={selectedItem}
                    isVisible={showOverlay}
                    onClose={handleOverlayClose}
                    onPlay={handlePlay}
                />
            )}
        </FocusContext.Provider>
    );
};

export default ContentGrid;