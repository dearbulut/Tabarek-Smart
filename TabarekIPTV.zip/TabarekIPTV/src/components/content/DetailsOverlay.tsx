import React, { useEffect, useCallback } from 'react';
import { useFocusable } from '@noriginmedia/norigin-spatial-navigation';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay, faClosedCaptioning, faHd, faStar, faClock, faCalendar } from '@fortawesome/free-solid-svg-icons';
import '../styles/DetailsOverlay.scss';

interface BaseContentDetails {
    id: string;
    title: string;
    description: string;
    backdropUrl: string;
    quality?: 'HD' | '4K';
    hasSubtitles?: boolean;
    rating?: number;
}

interface MovieSeriesDetails extends BaseContentDetails {
    type: 'movie' | 'series';
    year: number;
    duration: number; // in minutes
    genre?: string;
    cast?: string[];
}

interface LiveProgramDetails extends BaseContentDetails {
    type: 'live';
    channelName: string;
    startTime: string;
    endTime: string;
    category?: string;
}

type ContentDetails = MovieSeriesDetails | LiveProgramDetails;

interface DetailsOverlayProps {
    content: ContentDetails;
    isVisible: boolean;
    onClose: () => void;
    onPlay: (content: ContentDetails) => void;
}

export const DetailsOverlay: React.FC<DetailsOverlayProps> = ({
    content,
    isVisible,
    onClose,
    onPlay
}) => {
    const { ref: overlayRef, focusKey: overlayFocusKey } = useFocusable({
        isFocusBoundary: true
    });

    const { ref: playButtonRef, focused: playButtonFocused } = useFocusable({
        onEnterPress: () => onPlay(content),
        focusKey: `play-${content.id}`
    });

    const handleKeyDown = useCallback((event: KeyboardEvent) => {
        if (event.key === 'Escape' || event.key === 'Backspace') {
            onClose();
        }
    }, [onClose]);

    useEffect(() => {
        if (isVisible) {
            window.addEventListener('keydown', handleKeyDown);
        }
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isVisible, handleKeyDown]);

    const formatDuration = (minutes: number) => {
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;
        return `${hours}h ${remainingMinutes}m`;
    };

    return (
        <div 
            ref={overlayRef}
            className={`details-overlay ${isVisible ? 'visible' : ''}`}
            role="dialog"
            aria-modal="true"
        >
            <div className="backdrop">
                <img 
                    src={content.backdropUrl} 
                    alt=""
                    className="backdrop-image"
                />
                <div className="backdrop-gradient" />
            </div>

            <div className="content-details">
                <div className="metadata">
                    {content.quality && (
                        <span className="quality-badge">
                            {content.quality === '4K' ? '4K' : <FontAwesomeIcon icon={faHd} />}
                        </span>
                    )}
                    {content.hasSubtitles && (
                        <span className="subtitle-badge">
                            <FontAwesomeIcon icon={faClosedCaptioning} />
                        </span>
                    )}
                </div>

                <h2 className="title">{content.title}</h2>
                
                <div className="info-row">
                    {content.rating && (
                        <span className="rating">
                            <FontAwesomeIcon icon={faStar} />
                            {content.rating.toFixed(1)}
                        </span>
                    )}
                    
                    {'year' in content && (
                        <span className="year">
                            <FontAwesomeIcon icon={faCalendar} />
                            {content.year}
                        </span>
                    )}
                    
                    {'duration' in content ? (
                        <span className="duration">
                            <FontAwesomeIcon icon={faClock} />
                            {formatDuration(content.duration)}
                        </span>
                    ) : (
                        'startTime' in content && (
                            <span className="time">
                                <FontAwesomeIcon icon={faClock} />
                                {`${content.startTime} - ${content.endTime}`}
                            </span>
                        )
                    )}
                </div>

                <p className="description">{content.description}</p>

                {'genre' in content && content.genre && (
                    <div className="genre">{content.genre}</div>
                )}

                {'cast' in content && content.cast && (
                    <div className="cast">
                        <strong>Cast:</strong> {content.cast.join(', ')}
                    </div>
                )}

                {'channelName' in content && (
                    <div className="channel">
                        <strong>Channel:</strong> {content.channelName}
                    </div>
                )}

                <div 
                    ref={playButtonRef}
                    className={`play-button ${playButtonFocused ? 'focused' : ''}`}
                    role="button"
                    tabIndex={0}
                >
                    <FontAwesomeIcon icon={faPlay} />
                    <span>Play {content.type === 'series' ? 'Episode' : content.type === 'live' ? 'Channel' : 'Movie'}</span>
                </div>
            </div>
        </div>
    );
};

export default DetailsOverlay;